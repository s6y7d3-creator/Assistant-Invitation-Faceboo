# Fiche Google Play — brouillon

## Nom
Invitation Facebook

## Sous-titre
Organise tes contacts et prépare tes invitations Messenger.

## Description courte
Gère une liste de contacts, sélectionne les destinataires et prépare des invitations privées à envoyer manuellement.

## Description complète
Invitation Facebook est un assistant simple pour organiser les personnes que vous souhaitez contacter.

Fonctionnalités :
- Ajoutez manuellement des contacts avec leur nom et leurs liens de contact.
- Importez une liste CSV.
- Sélectionnez plusieurs contacts.
- Personnalisez votre message grâce à la variable {nom}.
- Copiez le message et ouvrez la conversation correspondante pour l'envoyer vous-même.
- Conservez votre liste localement sur votre appareil.

Respect de la confidentialité :
Vos données restent sur votre appareil. L'application ne collecte pas automatiquement les membres de groupes Facebook, ne se connecte pas à Facebook et n'envoie aucun message sans votre action.

Cette application indépendante n'est ni affiliée à Meta ni approuvée par Facebook ou Messenger.

Développé par SAVADOGO SYD IBRAYME.
