# Politique de confidentialité — Invitation Facebook

**Application :** Invitation Facebook  
**Développeur :** SAVADOGO SYD IBRAYME  
**Version :** 1.0.0

## Données traitées
L'application permet à l'utilisateur d'enregistrer localement les noms, liens de profils Facebook et liens ou identifiants Messenger qu'il saisit ou importe depuis un fichier CSV.

## Stockage et partage
Ces informations sont stockées dans les préférences privées de l'application sur l'appareil. L'application ne transmet pas ces données à un serveur exploité par le développeur et ne les vend ni ne les partage avec des tiers. L'application ne demande pas l'accès au carnet d'adresses, aux SMS, aux journaux d'appels ou aux services d'accessibilité.

Lorsqu'un utilisateur ouvre un lien Messenger ou Facebook, Android transmet ce lien à l'application compatible choisie par l'utilisateur. Les pratiques de confidentialité de cette application tierce sont régies par son propre fournisseur.

## Messages
L'application prépare et copie un texte d'invitation, puis ouvre le lien du destinataire. Elle n'envoie aucun message automatiquement. L'utilisateur vérifie le destinataire et déclenche lui-même l'envoi dans l'application tierce.

## Conservation et suppression
Les données restent sur l'appareil jusqu'à leur suppression depuis l'application ou jusqu'à la désinstallation de celle-ci. L'utilisateur peut supprimer chaque contact ou tous les contacts sélectionnés.

## Sécurité
L'application utilise le stockage privé Android et ne met en place aucune collecte distante. Protégez l'accès à votre appareil et ne partagez pas les exports contenant des données personnelles.

## Enfants
Cette application est un outil de gestion de contacts et n'est pas destinée spécifiquement aux enfants.

## Contact
Développeur : SAVADOGO SYD IBRAYME.  
Pour toute question relative à cette politique, contactez le développeur via les coordonnées indiquées sur la fiche officielle de l'application lorsqu'elle sera publiée.

Dernière mise à jour : 1 novembre 2026.
