# Invitation Facebook — projet Android

**Développé par SAVADOGO SYD IBRAYME**  
Version : 1.0.0  
Package : `com.sydibrayme.facebookinvitationassistant`

## Fonctionnalités
- Ajout manuel de contacts avec nom, URL de profil Facebook et URL/identifiant Messenger.
- Import CSV simple : colonnes `nom,lien_facebook,lien_messenger`.
- Sélection multiple, désélection et suppression.
- Modèle de message avec variable `{nom}`.
- Copie du message et ouverture de la conversation / du profil pour envoi manuel.
- Stockage local sur l'appareil.
- Aucune permission Contacts, SMS, Accessibilité ou Internet demandée.

## Limites et conformité
Cette application ne se connecte pas à Facebook, ne lit pas les membres d'un groupe, ne contourne pas les paramètres de confidentialité et n'envoie pas de messages automatiquement. L'utilisateur doit disposer d'un lien ou identifiant fourni volontairement et valider lui-même chaque message. Respectez les préférences des destinataires et les règles de Meta.

## Construire l'APK / AAB

Un workflow GitHub Actions est inclus dans `.github/workflows/android-build.yml` : après avoir envoyé le projet dans un dépôt GitHub, lancez l'action **Android build** depuis l'onglet Actions. Elle construit un APK debug téléchargeable comme artefact. Pour une version de production Play Store, suivez la procédure de signature ci-dessous.

Prérequis : Android Studio récent, JDK 17, Android SDK Platform 36 et Android Gradle Plugin 8.13.2.

1. Ouvrir ce dossier dans Android Studio.
2. Attendre la synchronisation Gradle.
3. Pour tester : **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. APK debug : `app/build/outputs/apk/debug/app-debug.apk`.
5. Pour Google Play : **Build > Generate Signed Bundle / APK > Android App Bundle**, créer et conserver une clé de signature privée, puis générer le `.aab` release.

Ne partagez jamais votre fichier de clé de signature ni ses mots de passe. Un AAB signé et un APK debug ne sont pas interchangeables.

## Avant publication
- Héberger la politique de confidentialité `PRIVACY_POLICY_FR.md` sur une URL publique HTTPS.
- Compléter la fiche Play Store, la section Sécurité des données et les déclarations de contenu.
- Tester sur plusieurs appareils et vérifier les liens Messenger.
- Google Play peut demander des tests préalables et des informations supplémentaires au compte développeur.
