package com.sydibrayme.facebookinvitationassistant;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

public class MainActivity extends Activity {
    private static final int PICK_CSV = 4101;
    private static final String PREFS = "invitation_assistant_local";
    private final ArrayList<Person> people = new ArrayList<>();
    private final ArrayList<Integer> queue = new ArrayList<>();
    private LinearLayout listContainer;
    private TextView countView, queueView;
    private EditText messageInput;
    private int queuePosition = 0;
    private int green, dark, ink, muted, surface, line;

    static class Person {
        String name, profile, messenger;
        boolean selected;
        Person(String n, String p, String m) { name=n; profile=p; messenger=m; }
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        green=0xFF176B45; dark=0xFF124D35; ink=0xFF17231C;
        muted=0xFF66756B; surface=0xFFFFFFFF; line=0xFFE2EAE4;
        loadPeople();
        buildUi();
    }

    private int dp(float v) { return (int)(v*getResources().getDisplayMetrics().density+0.5f); }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t=new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(color);
        if(bold) t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        return t;
    }

    private LinearLayout column() {
        LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l;
    }

    private LinearLayout row() {
        LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL); return l;
    }

    private void pad(View v,int a,int b,int c,int d) { v.setPadding(dp(a),dp(b),dp(c),dp(d)); }

    private GradientDrawableLike bg(View v, int color, int radius) {
        android.graphics.drawable.GradientDrawable d=new android.graphics.drawable.GradientDrawable();
        d.setColor(color); d.setCornerRadius(dp(radius)); v.setBackground(d);
        return null;
    }
    private static class GradientDrawableLike {}

    private TextView button(String label, boolean primary, Runnable action) {
        TextView b=text(label,14,primary?0xFFFFFFFF:green,true);
        b.setGravity(Gravity.CENTER); pad(b,16,13,16,13);
        bg(b,primary?green:0xFFE7F1EA,12);
        b.setOnClickListener(v->action.run());
        return b;
    }

    private void buildUi() {
        LinearLayout page=column(); page.setBackgroundColor(0xFFF4F7F5);
        LinearLayout header=column(); header.setBackgroundColor(dark); pad(header,20,22,20,20);
        header.addView(text("INVITATION FACEBOOK",12,0xFFCDE8D7,true));
        TextView title=text("Assistant d’invitation",23,0xFFFFFFFF,true); title.setPadding(0,dp(5),0,dp(4)); header.addView(title);
        header.addView(text("Organise tes contacts et prépare tes messages privés.",13,0xFFE1EFE6,false));
        page.addView(header);

        ScrollView scroll=new ScrollView(this);
        LinearLayout content=column(); pad(content,16,8,16,22);
        content.addView(sectionTitle("1. Ajouter un contact"));
        EditText name=edit("Nom ou prénom"); EditText profile=edit("Lien du profil Facebook (facultatif)");
        EditText messenger=edit("Lien m.me ou identifiant Messenger (facultatif)");
        content.addView(name); content.addView(profile); content.addView(messenger);
        LinearLayout addRow=row(); addRow.addView(button("Ajouter à ma liste",true,()->{
            String n=name.getText().toString().trim(), p=profile.getText().toString().trim(), m=messenger.getText().toString().trim();
            if(n.isEmpty()){toast("Entre le nom du contact.");return;}
            if(!p.isEmpty() && !p.startsWith("https://facebook.com/") && !p.startsWith("https://www.facebook.com/") && !p.startsWith("https://m.facebook.com/")){toast("Lien Facebook non reconnu.");return;}
            if(!m.isEmpty() && !m.startsWith("https://m.me/") && !m.matches("[A-Za-z0-9._]+")){toast("Entre un lien m.me ou un identifiant Messenger valide.");return;}
            people.add(new Person(n,p,m)); savePeople(); name.setText("");profile.setText("");messenger.setText("");renderPeople();
        }));
        addRow.addView(space(10)); addRow.addView(button("Importer CSV",false,this::pickCsv)); content.addView(addRow);

        content.addView(sectionTitle("2. Message d’invitation"));
        messageInput=new EditText(this); messageInput.setText("Bonjour {nom}, je souhaite t’inviter à découvrir mon initiative. Si cela t’intéresse, fais-moi signe. Merci !");
        messageInput.setTextSize(14); messageInput.setMinLines(4); messageInput.setGravity(Gravity.TOP); messageInput.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_SENTENCES|InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        pad(messageInput,12,10,12,10); bg(messageInput,surface,12); content.addView(messageInput);
        TextView hint=text("{nom} sera remplacé par le nom du destinataire. Le texte est copié avant l’ouverture de Messenger.",12,muted,false);
        hint.setPadding(0,dp(6),0,dp(2)); content.addView(hint);

        content.addView(sectionTitle("3. Ma liste de contacts"));
        LinearLayout controls=row();
        controls.addView(button("Tout cocher",false,()->{for(Person p:people)p.selected=true;renderPeople();}));
        controls.addView(space(6));
        controls.addView(button("Tout décocher",false,()->{for(Person p:people)p.selected=false;queue.clear();renderPeople();}));
        content.addView(controls);
        countView=text("0 contact",13,muted,true); countView.setPadding(0,dp(10),0,dp(5)); content.addView(countView);
        listContainer=column(); content.addView(listContainer);
        queueView=text("Aucun contact sélectionné.",12,muted,false); queueView.setPadding(0,dp(8),0,dp(8)); content.addView(queueView);
        content.addView(button("Préparer le prochain message",true,this::openNext));
        content.addView(button("Supprimer les contacts cochés",false,this::deleteSelected));
        content.addView(sectionTitle("Confidentialité et fonctionnement"));
        TextView privacy=text("Tes contacts et messages restent enregistrés localement sur cet appareil. L’application ne se connecte pas à Facebook, n’extrait pas les membres des groupes et n’envoie aucun message automatiquement. Tu dois ajouter les contacts toi-même et vérifier chaque destinataire avant l’envoi.",12,muted,false);
        pad(privacy,12,12,12,12); bg(privacy,0xFFFFF5DC,12); content.addView(privacy);
        TextView footer=text("Développé par SAVADOGO SYD IBRAYME · Version 1.0.0",12,muted,true);
        footer.setGravity(Gravity.CENTER); footer.setPadding(0,dp(20),0,dp(10)); content.addView(footer);

        scroll.addView(content); page.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(page); renderPeople();
    }

    private TextView sectionTitle(String s) {
        TextView t=text(s,17,ink,true); t.setPadding(0,dp(18),0,dp(9)); return t;
    }

    private EditText edit(String hint) {
        EditText e=new EditText(this); e.setSingleLine(true); e.setTextSize(14); e.setHint(hint);
        pad(e,12,7,12,7); bg(e,surface,11);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(48)); lp.bottomMargin=dp(8); e.setLayoutParams(lp); return e;
    }

    private View space(int width) { View v=new View(this); v.setLayoutParams(new LinearLayout.LayoutParams(dp(width),1)); return v; }

    private void renderPeople() {
        if(listContainer==null)return;
        listContainer.removeAllViews();
        int selected=0; for(Person p:people)if(p.selected)selected++;
        countView.setText(people.size()+" contact(s) · "+selected+" sélectionné(s)");
        queueView.setText(selected+" contact(s) prêt(s). L’envoi se fait un par un après vérification.");
        if(people.isEmpty()){TextView empty=text("Ta liste est vide. Ajoute un contact ou importe un fichier CSV.",13,muted,false);empty.setPadding(0,dp(12),0,dp(12));listContainer.addView(empty);return;}
        for(int i=0;i<people.size();i++){
            final int index=i; Person p=people.get(i);
            LinearLayout item=row(); pad(item,8,8,8,8); bg(item,surface,10);
            CheckBox cb=new CheckBox(this); cb.setButtonTintList(android.content.res.ColorStateList.valueOf(green)); cb.setChecked(p.selected);
            cb.setOnCheckedChangeListener((v,checked)->{p.selected=checked;renderPeople();});
            item.addView(cb);
            LinearLayout details=column(); details.addView(text(p.name,14,ink,true));
            String sub=!p.messenger.isEmpty()?p.messenger:(!p.profile.isEmpty()?p.profile:"Aucun lien de contact ajouté");
            TextView st=text(sub,11,muted,false); st.setMaxLines(1); st.setEllipsize(android.text.TextUtils.TruncateAt.END); details.addView(st);
            item.addView(details,new LinearLayout.LayoutParams(0,-2,1));
            TextView del=button("Retirer",false,()->{people.remove(index);savePeople();renderPeople();}); item.addView(del);
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2); lp.bottomMargin=dp(6); listContainer.addView(item,lp);
        }
    }

    private void openNext() {
        int index=-1;
        for(int i=0;i<people.size();i++)if(people.get(i).selected){index=i;break;}
        if(index<0){toast("Coche d’abord au moins un contact.");return;}
        Person p=people.get(index);
        String destination=!p.messenger.isEmpty()?p.messenger:p.profile;
        if(destination.isEmpty()){toast("Ajoute un lien Messenger ou un profil pour "+p.name+".");return;}
        if(!destination.startsWith("http"))destination="https://m.me/"+destination;
        String message=messageInput.getText().toString().replace("{nom}",p.name);
        ClipboardManager clipboard=(ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
        clipboard.setPrimaryClip(ClipData.newPlainText("Invitation",message));
        try {
            Intent intent=new Intent(Intent.ACTION_VIEW,Uri.parse(destination));
            startActivity(intent);
            p.selected=false; savePeople(); renderPeople();
            new AlertDialog.Builder(this).setTitle("Message préparé")
                .setMessage("La conversation de "+p.name+" est ouverte. Le texte a été copié si Android l’a autorisé. Colle-le, vérifie le destinataire et envoie-le manuellement.")
                .setPositiveButton("Compris",null).show();
        } catch(Exception ex) { toast("Impossible d’ouvrir ce lien. Vérifie le lien Messenger."); }
    }

    private void deleteSelected() {
        int before=people.size();
        for(int i=people.size()-1;i>=0;i--) if(people.get(i).selected) people.remove(i);
        int removed=before-people.size();
        savePeople(); renderPeople(); toast(removed+" contact(s) supprimé(s).");
    }

    private void pickCsv() {
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.setType("text/*"); i.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(i,PICK_CSV);
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==PICK_CSV && resultCode==RESULT_OK && data!=null) {
            try(InputStream in=getContentResolver().openInputStream(data.getData());
                BufferedReader br=new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
                String line; int added=0; boolean first=true;
                while((line=br.readLine())!=null) {
                    String[] c=line.split(",",-1);
                    if(first && c.length>0 && c[0].toLowerCase().contains("nom")){first=false;continue;}
                    first=false;
                    if(c.length>0 && !c[0].trim().isEmpty()) {
                        String n=unquote(c[0]), p=c.length>1?unquote(c[1]):"", m=c.length>2?unquote(c[2]):"";
                        people.add(new Person(n,p,m)); added++;
                    }
                }
                savePeople(); renderPeople(); toast(added+" contact(s) importé(s).");
            } catch(Exception e){toast("Lecture CSV impossible. Vérifie le format du fichier.");}
        }
    }
    private String unquote(String s){s=s.trim();if(s.startsWith("\"")&&s.endsWith("\"")&&s.length()>1)s=s.substring(1,s.length()-1);return s.replace("\"\"","\"");}

    private void savePeople() {
        JSONArray a=new JSONArray();
        try { for(Person p:people){JSONObject o=new JSONObject();o.put("name",p.name);o.put("profile",p.profile);o.put("messenger",p.messenger);o.put("selected",p.selected);a.put(o);} }
        catch(Exception ignored){}
        getSharedPreferences(PREFS,MODE_PRIVATE).edit().putString("people",a.toString()).apply();
    }
    private void loadPeople() {
        String raw=getSharedPreferences(PREFS,MODE_PRIVATE).getString("people","[]");
        try {JSONArray a=new JSONArray(raw);for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);Person p=new Person(o.optString("name"),o.optString("profile"),o.optString("messenger"));p.selected=o.optBoolean("selected",false);people.add(p);}}
        catch(Exception ignored){}
    }
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
}
